package com.example.cw4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static android.widget.Toast.LENGTH_SHORT;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText A = findViewById(R.id.editText);
        final EditText B = findViewById(R.id.editText1);
        TextView C = findViewById(R.id.textView);
        Button D = findViewById(R.id.button);

        D.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int num1 =Integer.parseInt(A.getText().toString());
                int num2 =Integer.parseInt(B.getText().toString());
                int sum =num1+num2;
                Toast.makeText(MainActivity.this, sum + "", LENGTH_SHORT).show();
            }
        });

    }
}